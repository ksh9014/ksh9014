package com.example.fileuploads;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FileuploadsApplicationTests {

	@Test
	void contextLoads() {
	}

}
